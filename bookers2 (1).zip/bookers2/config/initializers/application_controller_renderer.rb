# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '11845187335228dce0d33eb08ade0b80ed2336256ff0928592a3a98a96b15287b827f6b97377996cd881a4f32bc109e6cd26ff87bd4015bd54f951f1c2632e3b'
